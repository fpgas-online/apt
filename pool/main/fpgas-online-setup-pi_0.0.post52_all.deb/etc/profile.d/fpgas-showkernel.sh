uname -a
