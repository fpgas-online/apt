"""The check shared by the boards verified with the LiteX test designs: the Arty A7, NeTV2, Fomu EVT and TT FPGA.

On a board with JTAG (the Arty and the NeTV2) its whole IDCODE is read first and decoded (idcode.py): a part
that is not the variant's fails the board, whatever its silicon version. Once that scan has found the one FPGA
expected, its device DNA is read over the same JTAG (`openFPGALoader --read-dna`, dna.py), which loads nothing:
a DNA that cannot be read, or reads all zeros or all ones, fails the board too. Once both have passed, the SPI
flash's identity (JEDEC ID, unique ID, SFDP) is read with `openFPGALoader --flash-info-json` through its
SPI-over-JTAG bridge, which replaces the running design until the FPGA reloads from its flash: so before any
test design is loaded, and before the board is said to be identified, so fpga-board-identified carries it. A
read that fails is the identity's flash_error, and the board's result is error. For each of the board's boot-check
tests (UART, DDR, SPI flash): check its bitstream against the manifest of fpgas-online-<board>-bitstreams,
load it (into SRAM, except the Fomu's DFU), run its host test script and keep the tail of its output. Then,
where the board can, read back the region of its flash that holds the boot image, for the state (state.py):
loading test designs into SRAM does not touch the flash, so a flash that differs from the recorded one was
written by someone.

The board is left running the last design loaded. A board module is a TestBoard with its detection, its
programmer and its tests; `tests` maps a test to:

  artifact      the CI artifact path in the all-bitstreams bundle; {v} is the variant's suffix
  script        the host test script (host_tests.py), args its arguments; {port} is the board's UART
  verify        True if the boot check runs it; the others need extra wiring (fpgas-<board>-debug runs them)
  pre           commands to run first (each may fail)
  runner        "tt-bridge": the script runs through the TT board's RP2350, which also loads the design
  listen        True if the script must have the UART open before the design starts (listen.py)
  says          a prefix: when the script fails, its last line starting with it is the reason (else "the test
                exited N"), and an exit of 2 under it is an error (it could not read), not a fail
"""

import contextlib
import hashlib
import json
import re
import sys
import tempfile
from typing import ClassVar

from . import bitstreams, checks, dna, host_tests, idcode, identity
from .board import Board
from .core import Problem, host_facts, run, tail, usb_matching, worst

PROGRAM_TIMEOUT = 300
TEST_TIMEOUT = 300
DUMP_TIMEOUT = 900
JTAG_TIMEOUT = 60
# Loading the SPI-over-JTAG bridge (a whole bitstream: over libgpiod on a Pi 3/4) and reading the flash's IDs.
FLASH_INFO_TIMEOUT = PROGRAM_TIMEOUT
# Why the device DNA was not read when the IDCODE scan did not pass.
DNA_SKIPPED = "not read: --read-dna runs only once the JTAG scan has found the one FPGA expected"
# Why the flash's identity was not read when the JTAG check did not pass.
FLASH_INFO_SKIPPED = ("not read: --flash-info-json runs only once the JTAG check has passed (the one FPGA expected, "
                      "and its device DNA)")  # fmt: skip
JEDEC_RE = re.compile(r"JEDEC ID: 0x([0-9A-Fa-f]{2}) 0x([0-9A-Fa-f]{2}) 0x([0-9A-Fa-f]{2})")


# openFPGALoader's last line after loading a 7-series FPGA over JTAG: "ir: 1 isc_done 1 isc_ena 0 init 1 done 1".
DONE_RE = re.compile(r"^ir: [0-9a-f]+ isc_done [01] isc_ena [01] init [01] done ([01])\s*$", re.M)
# listen.py's line when the programmer exited non-zero.
LISTEN_LOAD_FAILED = re.compile(r"^loading the design failed \(exit (\d+)\)$", re.M)


class TestBoard(Board):
    usb = ()  # (vendor, product) pairs that mean this board, product None for any
    variants: ClassVar[dict] = {}  # variant -> artifact suffix
    port = ""
    tests: ClassVar[dict] = {}
    doc = ""

    # A 7-series FPGA loaded over JTAG by openFPGALoader: it exits 0 even when the FPGA did not configure (#300),
    # so the load is judged by the `done` bit it prints last (load_failure).
    jtag_loads_7_series = False

    # -- what varies by board ------------------------------------------------------------------------------

    def program_argv(self, bitstream, host, test):
        raise NotImplementedError

    def load_failure(self, argv, text):
        """Why a load that exited 0 did not configure the FPGA, or None. Only an openFPGALoader load of a 7-series
        FPGA over JTAG is judged: its last lines end with `ir: … done 1` when it configured (src/xilinx.cpp,
        Xilinx::program_mem), and it exits 0 either way."""
        if not (self.jtag_loads_7_series and argv and argv[0] == "openFPGALoader"):
            return None
        done = DONE_RE.findall(text)
        if not done:
            return "openFPGALoader printed no 'done' line, so whether the FPGA configured is not known"
        if done[-1] != "1":
            return "the FPGA did not configure: openFPGALoader's last line says done 0 (it exits 0 all the same)"
        return None

    def flash_argv(self, host, variant):
        """openFPGALoader with the cable and FPGA part that reach the board's SPI flash through its SPI-over-JTAG
        bridge, for the flash's readback and its identity; None for a board whose flash is not read so."""
        return None

    def flash_dump_argv(self, host, variant, size, out):
        """openFPGALoader reading `size` bytes of flash from 0 into `out`; None if not possible."""
        argv = self.flash_argv(host, variant)
        return None if argv is None else [*argv, "--dump-flash", "--file-size", str(size), out]

    def flash_info_argv(self, host, variant, out):
        """openFPGALoader writing the flash's identity to `out` (--flash-info-json, the fpgas.online builds'),
        through the same bridge as the readback; None if not possible."""
        argv = self.flash_argv(host, variant)
        return None if argv is None else [*argv, "--flash-info-json", out]

    # A board with JTAG: variant -> its FPGA's IDCODE at version 0. The check reads the whole IDCODE (from
    # `found`, when finding the board read it, else with idcode_argv) and fails a part that is not the variant's.
    # A `found` with an IDCODE also has the scan that read it: {"idcode_scan": {"tool", "exit", "output"}}, and
    # every IDCODE that scan saw on the chain, in order: {"idcodes": ["0x...", ...]}.
    idcodes: ClassVar[dict] = {}

    def idcode_argv(self, host):
        """The command that scans the board's JTAG chain and prints whole IDCODEs (idcode.parse)."""
        raise NotImplementedError

    def dna_argv(self, host):
        """openFPGALoader --read-dna over the board's JTAG: the same cable and pins as the IDCODE scan."""
        raise NotImplementedError

    @contextlib.contextmanager
    def jtag_driven(self, runner, faults):
        """Held around a JTAG read that drives the Pi's own pins (the NeTV2's), so they are put back afterwards;
        what goes wrong putting them back is added to `faults`. A board on USB drives none of the Pi's pins."""
        yield

    flash_region: ClassVar[dict] = {}  # variant -> bytes of flash holding the boot image (a whole .bit for that part)
    flash_note = ""  # when there is no readback: why the flash is not part of the state
    # systemd units that hold the board's port while they run (the TT site's bridge, fpgas-tt, holds the TT
    # board's /dev/ttyACM0): stopped for the tests, and started again after if they were running.
    services: ClassVar[tuple] = ()

    @contextlib.contextmanager
    def services_stopped(self, runner=run, later=None):
        """Stop whichever of `services` are running; start them again on the way out, whatever happened.

        With `later` (a list), the units stopped are added to it instead of being started: the caller starts
        them once it has written its report (runner.run), so a service that reads the report when it starts
        never reads the one before.

        Yields {"stopped": [...], "failed": [...]}: a unit that would not stop, or whose start could not be
        queued, is in "failed" (the check makes that an error: the service may be left down). The start is
        --no-block: fpgas-verify.service is ordered Before= fpgas-tt, so a blocking start from inside its
        ExecStart (a `systemctl restart fpgas-verify`) would wait on the verify's own start job; queued, it
        runs as soon as the verify is done. At boot the bridge is not running yet (its start waits for the
        verify), so nothing is stopped."""
        held = {"stopped": [], "failed": []}
        for unit in self.services:
            try:
                if runner(["systemctl", "is-active", "--quiet", unit], 30)[0] != 0:
                    continue
                rc, text = runner(["systemctl", "stop", unit], 60)
            except Problem as p:
                rc, text = 1, p.reason
            if rc == 0:
                held["stopped"].append(unit)
            else:
                held["failed"].append(f"{unit} would not stop: {' '.join(tail(text, 2))}")
        try:
            yield held
        finally:
            if later is not None:
                later.extend(unit for unit in held["stopped"] if unit not in later)
            for unit in held["stopped"] if later is None else ():
                try:
                    rc, text = runner(["systemctl", "start", "--no-block", unit], 60)
                except Problem as p:
                    rc, text = 1, p.reason
                if rc != 0:
                    held["failed"].append(f"{unit} was not started again: {' '.join(tail(text, 2))}")

    # -- detection -----------------------------------------------------------------------------------------

    def spot(self, host, usb, pci):
        variant = next(iter(self.variants))
        return [{"variant": variant, "usb": d["path"], "serial": d["serial"]} for d in usb_matching(usb, self.usb)]

    # -- the tests -----------------------------------------------------------------------------------------

    @property
    def verify_tests(self):
        return [name for name, t in self.tests.items() if t.get("verify")]

    @property
    def bitstreams_package(self):
        return f"fpgas-online-{self.slug}-bitstreams"

    def artifact(self, test, variant):
        return self.tests[test]["artifact"].format(v=self.variants[variant])

    def facts(self, port=None):
        return {**host_facts(), "port": port or self.port}

    def uart_pre(self, host):
        """Free the board's UART on the Pi: no login console on it."""
        import os

        port = host["port"]
        if not port.startswith(("/dev/tty", "/dev/serial")):
            return []
        return [["systemctl", "stop", f"serial-getty@{os.path.basename(os.path.realpath(port))}.service"]]

    def pre_steps(self, test, host):
        t = self.tests[test]
        steps = list(t.get("pre", []))
        if "{port}" in " ".join(t["args"]) and t.get("runner") != "tt-bridge":
            steps += self.uart_pre(host)
        return steps

    def test_argv(self, test, host, bitstream):
        t = self.tests[test]
        script = [sys.executable, host_tests.path(t["script"]), *(a.format(port=host["port"]) for a in t["args"])]
        if t.get("runner") == "tt-bridge":
            return [sys.executable, host_tests.path("tt_test_wrapper.py"), host["port"], bitstream, *script]
        return script

    def bitstream(self, images, manifest, test, variant):
        entry = bitstreams.entry_for(manifest, self.artifact(test, variant), self.bitstreams_package)
        return bitstreams.checked(images, entry)[0]

    @staticmethod
    def judged(t, rc, text):
        """A host script's result from its exit and output: {result, output, reason?, flash_jedec?}. With `says`,
        its last line starting with that prefix is the reason, and an exit of 2 is an error."""
        found = {"result": "pass" if rc == 0 else "fail", "output": tail(text)}
        if rc != 0:
            found["reason"] = f"the test exited {rc}"
            prefix = t.get("says")
            said = [line[len(prefix) :].strip() for line in text.splitlines() if prefix and line.startswith(prefix)]
            if said and said[-1]:  # the script's own last word on why
                found["reason"] = said[-1]
                if rc == 2:  # it could not make its reading at all
                    found["result"] = "error"
        m = JEDEC_RE.search(text)
        if m:
            found["flash_jedec"] = "0x" + "".join(m.groups()).lower()
        return found

    def run_test(self, test, variant, host, images, manifest, runner=run):
        t = self.tests[test]
        out = {"test": test, "bitstream": self.artifact(test, variant)}
        try:
            bitstream = self.bitstream(images, manifest, test, variant)
            for step in self.pre_steps(test, host):
                with contextlib.suppress(Problem):
                    runner(step, 30)
            if t.get("listen"):  # the test must be listening before the design starts: listen.py
                test_argv = self.test_argv(test, host, bitstream)
                program = self.program_argv(bitstream, host, test)
                argv = [sys.executable, "-m", "fpgas_online_verify.listen", host["port"], str(len(test_argv)),
                        *test_argv, *program]  # fmt: skip
                rc, text = runner(argv, PROGRAM_TIMEOUT + TEST_TIMEOUT + 60)  # more than listen.py allows itself
                # listen.py says a programmer that exited non-zero in its own words; otherwise the load is judged
                # by its output, which listen.py passes on (the test may pass on stale output: the load says first)
                failed = LISTEN_LOAD_FAILED.search(text)
                if failed:
                    return {**out, "result": "fail", "reason": f"loading it failed (exit {failed[1]})",
                            "output": tail(text)}  # fmt: skip
                why = self.load_failure(program, text)
                if why:
                    return {**out, "result": "fail", "reason": f"loading it failed: {why}", "output": tail(text)}
            else:
                if t.get("runner") != "tt-bridge":  # the bridge loads the design itself
                    program = self.program_argv(bitstream, host, test)
                    rc, text = runner(program, PROGRAM_TIMEOUT)
                    if rc != 0:
                        return {**out, "result": "fail", "reason": f"loading it failed (exit {rc})",
                                "output": tail(text)}  # fmt: skip
                    why = self.load_failure(program, text)
                    if why:
                        return {**out, "result": "fail", "reason": f"loading it failed: {why}", "output": tail(text)}
                rc, text = runner(self.test_argv(test, host, bitstream), TEST_TIMEOUT)
        except Problem as p:
            return {**out, "result": p.result, "reason": p.reason}
        return {**out, **self.judged(t, rc, text)}

    def before_test(self, test, variant, host, report, runner=run):
        """What the board needs before `test` loads its design: None when it may go ahead, else the test's entry
        saying why it was not loaded. Nothing, except on a board whose test designs undo what the next load needs
        (the Fomu: Fomu.before_test)."""
        return None

    def script_tests_for(self, variant):
        return [name for name, t in self.script_tests.items() if variant in t["variants"]]

    def script_values(self, facts):
        """What a script test's `args` may name besides {port}, from what the board said (port_facts): nothing,
        except on a board whose script needs to be told what the board is (TTFPGA.script_values). Raises Problem
        when the board did not say it."""
        return {}

    def run_script_test(self, test, host, runner=run, facts=None):
        """A script test (script_tests): its `pre` steps, then its script on the board's port; nothing is loaded.
        A script the check had to kill at its limit could not finish, and could not put back what it changed: an
        error, not a fail. So is a script that could not be told what its `args` name: it is not run."""
        t = self.script_tests[test]
        try:
            values = {"port": host["port"], **self.script_values(facts or {})}
            argv = [sys.executable, host_tests.path(t["script"]), *(a.format(**values) for a in t["args"])]
        except Problem as p:
            return {"test": test, "result": "error", "reason": p.reason}
        try:
            for step in t.get("pre", []):
                with contextlib.suppress(Problem):
                    runner(step, 30)
            rc, text = runner(argv, t.get("timeout", TEST_TIMEOUT))
        except Problem as p:
            reason = p.reason
            if "did not finish within" in reason:  # core.run names the interpreter: say which test it was
                reason = f"the {test} test did not finish within {t.get('timeout', TEST_TIMEOUT)} s"
            return {"test": test, "result": "error", "reason": reason}
        return {"test": test, **self.judged(t, rc, text)}

    # -- JTAG ------------------------------------------------------------------------------------------------

    def jtag(self, host, found, variant, runner=run):
        """The board's IDCODE, decoded, against its variant's part, and then its device DNA:
        {result, reason?, idcode, idcode_version, ..., dna or dna_error}."""
        return self.read_dna(host, self.read_idcode(host, found, variant, runner), runner)

    def read_idcode(self, host, found, variant, runner=run):
        """The board's IDCODE, decoded, against its variant's part: {result, reason?, idcode, idcode_version, ...}."""
        want = self.idcodes[variant]
        output, scan_faults = [], []
        if found.get("idcode"):  # read when the board was found (the NeTV2's scan)
            codes = [int(c, 16) for c in found.get("idcodes") or [found["idcode"]]]
            scan = found["idcode_scan"]
            output = scan["output"]
            if scan["exit"] != 0:  # whatever it printed, a scan that failed is not trusted
                scan_faults.append(f"{scan['tool']} exited {scan['exit']} reading the IDCODE")
        else:
            argv = self.idcode_argv(host)
            try:
                rc, text = runner(argv, JTAG_TIMEOUT)
            except Problem as p:
                return {"result": p.result, "reason": f"the JTAG chain could not be scanned: {p.reason}"}
            codes = idcode.parse(text)
            output = (codes and rc == 0 and idcode.scan_lines(text)) or tail(text, 6)
            if rc != 0:  # whatever it printed, a scan that failed is not trusted
                scan_faults.append(f"{argv[0]} exited {rc} reading the IDCODE")
            if not codes:
                if idcode.empty_chain(text):
                    reason = "; ".join(["no device on the JTAG chain", *scan_faults])
                elif rc != 0:
                    reason = idcode.scan_failed(argv[0], rc, text)
                else:
                    reason = idcode.NO_RAW_SCAN
                return {"result": "fail", "reason": reason, "output": output}
        entry = {**idcode.decode(codes[0]), **({"output": output} if output else {})}
        faults = idcode.faults(codes[0])
        if len(codes) != 1:
            entry["idcode"] = ", ".join(f"{c:#010x}" for c in codes)
            faults.append(f"the JTAG chain has {len(codes)} devices ({entry['idcode']}), not one")
        elif not idcode.same_part(codes[0], want):
            faults.append(f"the JTAG IDCODE {entry['idcode']} is an {entry['idcode_device']}, not the {variant}'s "
                          f"{idcode.device(want)} (IDCODE {want:#010x}, any version)")  # fmt: skip
        faults += scan_faults
        return {**entry, "result": "fail", "reason": "; ".join(faults)} if faults else {**entry, "result": "pass"}

    def read_dna(self, host, entry, runner=run):
        """The JTAG entry with the device DNA added (dna, 16 hex digits), or dna_error saying why there is none.
        It is read only once the IDCODE scan passed (one device, the variant's part); FUSE_DNA reconfigures
        nothing. A DNA that cannot be read, or that reads all zeros or all ones (dna.faults), fails the entry."""
        if entry["result"] != "pass":
            return {**entry, "dna_error": DNA_SKIPPED}
        argv = self.dna_argv(host)
        faults, driven = [], []  # driven: what went wrong putting the Pi's JTAG pins back
        text = ""
        try:
            with self.jtag_driven(runner, driven):
                rc, text = runner(argv, JTAG_TIMEOUT)
        except Problem as p:
            faults.append((p.result, f"the device DNA could not be read: {p.reason}"))
        else:
            value = dna.parse(text) if rc == 0 else None
            if value is None:
                last = (tail(text, 1) or ["no output"])[0].strip()
                faults.append(("fail", f"openFPGALoader --read-dna read no device DNA (exit {rc}): {last}"))
            else:
                faults += [("fail", f) for f in dna.faults(value, "JTAG")]
        out = {**entry, "output": [*entry.get("output", []), *tail(text, 4)]}
        if faults:
            out["dna_error"] = "; ".join(reason for _, reason in faults)
        else:
            out["dna"] = identity.dna(value)
        faults += [("error", f) for f in driven]
        if not faults:
            return out
        result = "error" if all(r == "error" for r, _ in faults) else "fail"
        return {**out, "result": result, "reason": "; ".join(reason for _, reason in faults)}

    # -- the flash -----------------------------------------------------------------------------------------

    def read_flash_identity(self, host, variant, jtag, runner=run):
        """(the identity's flash fields, the faults that make the check an error) from `openFPGALoader
        --flash-info-json` (identity.flash_info_fields), run once the JTAG entry `jtag` has passed and held in
        jtag_driven as the DNA read is. ({}, []) for a board whose flash is not read over JTAG.

        The bridge replaces the running design, then the FPGA reloads from its flash: so it is read before any
        test design is loaded, and never by --identify. A read that fails (the command could not run, exited
        non-zero, wrote no file, or wrote one this does not take) is flash_error with why, and a fault; one not
        tried because the JTAG check did not pass is flash_error (FLASH_INFO_SKIPPED) only: the jtag test has
        already failed the board."""
        with tempfile.TemporaryDirectory() as tmp:
            out = f"{tmp}/flash-info.json"
            argv = self.flash_info_argv(host, variant, out)
            if argv is None:
                return {}, []
            if jtag.get("result") != "pass":
                return {"flash_error": FLASH_INFO_SKIPPED}, []
            driven = []  # what went wrong putting the Pi's JTAG pins back
            try:
                with self.jtag_driven(runner, driven):
                    rc, text = runner(argv, FLASH_INFO_TIMEOUT)
            except Problem as p:
                why = f"openFPGALoader --flash-info-json could not be run: {p.reason}"
                return {"flash_error": why}, [f"flash_error: {why}", *self._after_flash_info(driven)]
            last = " ".join(tail(text, 2)) or "no output"
            try:
                with open(out, "rb") as f:
                    written = f.read()
            except FileNotFoundError:
                written = None
            if rc != 0:  # it writes no file then; one there is not trusted either
                why = f"openFPGALoader --flash-info-json exited {rc}: {last}"
            elif written is None:
                why = f"openFPGALoader --flash-info-json exited 0 and wrote no file: {last}"
            else:
                try:
                    fields = identity.flash_info_fields(json.loads(written), "jtag")
                except ValueError as e:  # UnicodeDecodeError too
                    fields = {"flash_error": f"openFPGALoader --flash-info-json wrote a file that is not JSON: {e}"}
                why = fields.get("flash_error")
                if why is None:
                    return fields, self._after_flash_info(driven)
            return {"flash_error": why}, [f"flash_error: {why}", *self._after_flash_info(driven)]

    @staticmethod
    def _after_flash_info(driven):
        return [f"after openFPGALoader --flash-info-json: {fault}" for fault in driven]

    def read_flash(self, host, variant, runner=run):
        """{"region_bytes", "sha256"} of the boot image region, read back over JTAG."""
        size = self.flash_region.get(variant)
        with tempfile.TemporaryDirectory() as tmp:
            out = f"{tmp}/flash.bin"
            argv = self.flash_dump_argv(host, variant, size, out) if size else None
            if argv is None:
                return None
            rc, text = runner(argv, DUMP_TIMEOUT)
            try:
                with open(out, "rb") as f:
                    data = f.read()
            except OSError:
                data = b""
            if rc != 0 or len(data) != size:
                raise Problem("error", f"reading back the flash failed (exit {rc}, {len(data)} of {size} bytes): "
                                       f"{' '.join(tail(text, 3))}")  # fmt: skip
            return {"region_bytes": size, "sha256": hashlib.sha256(data).hexdigest()}

    # -- the check -----------------------------------------------------------------------------------------

    def identity(self, found):
        return {k: v for k, v in found.items() if k in ("variant", "serial", "idcode", "dna") and v is not None}

    def port_facts(self, host, found, runner=run):
        """Identity fields only the board's own port gives, read while `services` are stopped and before any
        test (the TT FPGA's, from rpi-hwid): {} for a board with none. A read that was tried and failed is a
        <field>_error, which makes the check an error."""
        return {}

    # A board whose variant finding it does not give (the Tiny Tapeout demo board: an RP2 on USB is the same
    # whatever chip it carries): `found` has no variant, and settle() decides it from what the board itself
    # said (port_facts), before any design is chosen. Other boards leave this False and nothing changes for
    # them.
    variant_from_board = False
    # Tests judged from what the board itself said (port_facts), which load nothing: test -> {"variants": the
    # variants it is for, "check": f(variant, facts, found) giving (result, the reason or None, lines for the
    # report)}. `found` is how the board was found, with what port_facts left in it (the Fomu's header reading,
    # which is not an identity field).
    # They run first, in the whole boot check only (not when single tests were asked for), and are the whole
    # check of a variant that no bitstream here is for (a demo board with a Tiny Tapeout chip).
    fact_tests: ClassVar[dict] = {}
    # Tests that run a host script against the board's port and load nothing (the Pmod wiring test of a demo
    # board with a Tiny Tapeout chip): test -> {"variants": the variants it is for, "script", "args" ({port} is
    # the board's port), "pre" (commands run first, each may fail), "says" and "timeout" as a test's, and
    # "needs": fact tests that must have passed for it to mean anything (when one did not, it is not run, and
    # the report's not_run says why)}. They run after the fact tests, in the whole boot check only, with the
    # board's `services` stopped.
    script_tests: ClassVar[dict] = {}
    # variant -> {test: why}: a test that variant must have and the boot check does not run yet. It goes in the
    # report's `not_run`, and the board FAILS with that reason: a board is not passed on a check that leaves
    # out a test it needs (Tim, 2026-10-05: "Fail until wiring is tested"). Its other tests still run and are
    # reported, so the report shows what is known of the board.
    pending: ClassVar[dict] = {}

    # variant -> a design the check loads last and leaves running, which is no test: nothing reads it (the TT
    # FPGA's moving display, #139): {"design": its name, "artifact": as a test's}.
    # It is in the board's bitstreams package beside the tests' designs. A load that fails is a warning in the
    # report, never the board's result: the board was tested before it, and is left as its last test left it.
    left_running: ClassVar[dict] = {}

    # What the whole check is asked about (checks.py, #340): variant -> {test: the test-designs issue that adds it}
    # for a test the board's hardware calls for and the check does not run yet (planned, and not run with
    # checks.NO_TEST_YET; it fails the board while checks.UNTESTED_FAILS, Tim's coord-64), and variant -> {common
    # check: why the board cannot have it}.
    not_yet: ClassVar[dict] = {}
    cannot: ClassVar[dict] = {}
    # The test entry finish() adds, when it adds one (the Fomu's foboot-after): planned last.
    closing_test = None
    # variant -> {test: (source tests, what they cover)}: a test derived from others (checks.derive), planned before
    # closing_test (the wiring of a board whose header lines each have a test of their own).
    derives: ClassVar[dict] = {}
    # What each test checks, one line (Board.about, #346): {test: text}, and variant -> {test: text} where a test
    # means another thing on another variant (the TT board's `wiring`). A derived test's is its derives text.
    abouts: ClassVar[dict] = {}
    abouts_by_variant: ClassVar[dict] = {}
    # A board with variant_from_board whose variant was not settled: what its check would still have run.
    planned_unsettled = ()

    def untested(self, variant):
        return dict(self.not_yet.get(variant, {}))

    def not_applicable(self, variant, found=None):
        return {**self.cannot.get(variant, {}), **self.unwired(found)}

    def unwired(self, found):
        """{test: why} for the tests of wires this host does not have (the TT board's `wiring` on a Pi with no
        Pmod HAT: TTFPGA.unwired), from how the board was found. Such a test is not planned and not run, and is
        in the report's not_applicable with that reason, and in its warnings: it does not fail the board, since
        there is nothing of it to test. {} when `found` does not say, so a host that is not known to lack the
        wires is tested."""
        return {}

    def derived(self, variant, found=None):
        return dict(self.derives.get(variant, {}))

    def about(self, variant, found=None):
        derived = {test: text for test, (_, text) in self.derived(variant, found).items()}
        return {**self.abouts, **self.abouts_by_variant.get(variant, {}), **derived}

    def planned(self, variant, options=None, found=None):
        unwired = self.unwired(found)
        if variant is None and self.variant_from_board:
            return [t for t in self.planned_unsettled if t not in unwired]
        out = ["jtag"] if variant in self.idcodes else []
        out += self.fact_tests_for(variant) + self.script_tests_for(variant)
        out += self.verify_tests if variant in self.variants else []
        out += [t for t in self.untested(variant) if t not in out]
        out += [t for t in self.derived(variant) if t not in out]
        out = [t for t in out if t not in unwired]
        return out + ([self.closing_test] if self.closing_test else [])

    def artifacts(self):
        """[(test or design name, variant, artifact path)]: every bitstream the bitstreams package holds."""
        out = [(test, variant, self.artifact(test, variant)) for test in self.tests for variant in self.variants]
        return out + [(spec["design"], variant, spec["artifact"]) for variant, spec in self.left_running.items()]

    def leave_running(self, variant, host, images, manifest, runner=run):
        """Load the variant's left_running design: (what the report says was left running, None), or
        (None, why it could not be loaded). Never raises."""
        spec = self.left_running[variant]
        try:
            entry = bitstreams.entry_for(manifest, spec["artifact"], self.bitstreams_package)
            bitstream = bitstreams.checked(images, entry)[0]
            argv = self.program_argv(bitstream, host, None)
            rc, text = runner(argv, PROGRAM_TIMEOUT)
        except Problem as p:
            return None, p.reason
        if rc != 0:
            return None, f"loading it failed (exit {rc}): {' '.join(tail(text, 2))}"
        why = self.load_failure(argv, text)
        if why:
            return None, f"loading it failed: {why}"
        return {"design": spec["design"], "bitstream": spec["artifact"]}, None

    def settle(self, asked, found, facts):
        """The variant of a board with variant_from_board, from `facts`; `asked` is --variant, or None. It is one
        of `variants` or one a fact test is for, or a Problem saying why the board is not checked: then no test
        runs and nothing is loaded."""
        raise NotImplementedError

    def fact_tests_for(self, variant):
        return [name for name, t in self.fact_tests.items() if variant in t["variants"]]

    def finish(self, variant, host, found, report, runner=run):
        """A last step after every test, judged like one: a test entry, or None for nothing to do. The Fomu
        resets its iCE40 so foboot is on USB for the next user (#135)."""
        return None

    def run_fact_test(self, test, variant, facts, found=None):
        result, reason, output = self.fact_tests[test]["check"](variant, facts, found or {})
        return {"test": test, "result": result, **({"reason": reason} if reason else {}), "output": list(output)}

    def identified(self, report, found, options, facts=None):
        """Who the board is (identity.py), from how it was found, its JTAG IDCODE and DNA, and `facts`
        (port_facts): put in the report and sent as fpga-board-identified, before any test runs."""
        out = identity.base(options.get("board_key", self.name), self.name, found, report["variant"])
        if "jtag" in report:
            out.update(identity.idcode_fields(report["jtag"]))
            out.update(identity.dna_fields(report["jtag"]))
        out.update(facts or {})
        report["identity"] = out
        identity.keep(options, out)
        (options.get("event") or (lambda stage, details: None))("fpga-board-identified", identity.details(out))

    # The flash (its identity, and the readback) is read through openFPGALoader's SPI-over-JTAG bridge, which
    # replaces the running design: --identify takes the flash's fields from the boot report.
    report_fields = ("flash",)

    def identify(self, host, found, options, runner=run):
        """How the board was found, and its IDCODE and device DNA over JTAG on a board with JTAG: nothing is
        loaded and nothing is reconfigured. So the flash's identity is not read (read_flash_identity loads the
        SPI-over-JTAG bridge in place of the running design): its fields come from the boot report
        (report_fields, identify.from_report)."""
        variant = options.get("variant") or found["variant"]
        out = identity.base(options.get("board_key", self.name), self.name, found, variant)
        if self.idcodes and variant in self.idcodes:
            jtag = self.jtag(host, found, variant, runner)
            out.update(identity.idcode_fields(jtag))
            out.update(identity.dna_fields(jtag))
        return out

    def check(self, host, found, options, runner=run):
        late = self.variant_from_board  # the variant is settled from the board's own word, once its port is ours
        variant = options.get("variant") or found["variant"]
        report = {"board": self.name, "variant": None if late else variant, "found": found, "tests": []}
        images = bitstreams.images_dir(self.slug, options.get("images"))
        tests = self.verify_tests if options.get("tests") is None else options["tests"]
        manifest, refused = None, None
        try:
            unknown = [t for t in tests if t not in self.tests]
            if unknown:
                raise Problem(
                    "error", f"{self.title} has no test {', '.join(unknown)} (it has {', '.join(self.tests)})"
                )
            if not late:
                if variant not in self.variants:
                    raise Problem("error", f"{found} is no {self.title} variant this package has bitstreams for "
                                           f"({', '.join(self.variants)})")  # fmt: skip
                manifest = bitstreams.load_manifest(images, self.bitstreams_package)
        except Problem as p:
            self.identified(report, found, options)
            return {**report, "result": p.result, "reason": p.reason}
        if manifest is not None:
            report["bitstreams"] = manifest.get("version")
        event = options.get("event") or (lambda stage, details: None)
        if self.idcodes and not late:  # a JTAG part is a variant's: none is known yet for a late one
            # Reported as the board's first test too (#340), and kept whole under "jtag" for the identity.
            event("fpga-test-started", {"test": "jtag"})
            jtag = report["jtag"] = self.jtag(host, found, variant, runner)
            report["tests"].append({"test": "jtag", "result": jtag["result"],
                                    **({"reason": jtag["reason"]} if "reason" in jtag else {}),
                                    "output": list(jtag.get("output", []))})  # fmt: skip
            event("fpga-test-finished", {"test": "jtag", "result": jtag["result"], "reason": jtag.get("reason", "")})
            # Before any design is loaded (the bridge replaces it) and before fpga-board-identified, which
            # carries what it read: the one event keyed by how the board was found.
            flash_ident, flash_faults = self.read_flash_identity(host, variant, jtag, runner)
        else:
            flash_ident, flash_faults = {}, []
        not_yet = {}  # the planned tests not written yet (checks.NO_TEST_YET)
        with self.services_stopped(runner, options.get("restart_later")) as held:
            facts = self.port_facts(host, found, runner)
            if late:
                try:
                    variant = report["variant"] = self.settle(options.get("variant"), found, facts)
                    if variant in self.variants:
                        manifest = bitstreams.load_manifest(images, self.bitstreams_package)
                        report["bitstreams"] = manifest.get("version")
                    elif not options.get("tests"):  # no design is for it: its fact tests are its check
                        tests = []
                    else:
                        raise Problem("error", f"the board is a {variant}: {', '.join(tests)} "
                                               f"{'is' if len(tests) == 1 else 'are'} for a "
                                               f"{' or '.join(self.variants)}, so nothing was loaded")  # fmt: skip
                except Problem as p:  # not settled, or no bitstreams: no test runs and nothing is loaded
                    refused, tests = p, []
            self.identified(report, found, options, {**facts, **flash_ident})
            # No test named (None, or an empty list, which names none): the board's own word is judged.
            for test in self.fact_tests_for(variant) if not options.get("tests") and not refused else ():
                event("fpga-test-started", {"test": test})
                report["tests"].append(self.run_fact_test(test, variant, facts, found))
                done = report["tests"][-1]
                event("fpga-test-finished", {"test": test, "result": done["result"], "reason": done.get("reason", "")})
            not_run = dict(self.pending.get(variant, {})) if not refused else {}
            # Wires this host does not have are not tested in the whole check; a test asked for by name is run.
            unwired = {} if options.get("tests") else self.unwired(found)
            if not refused and not options.get("tests"):
                not_yet = checks.untested_reasons(self.untested(variant))
                not_run.update({t: why for t, why in not_yet.items() if t not in not_run})
            for test in self.script_tests_for(variant) if not options.get("tests") and not refused else ():
                if test in unwired:
                    report.setdefault("warnings", []).append(f"{test} not tested: {unwired[test]}")
                    continue
                failed = [
                    t["test"]
                    for t in report["tests"]
                    if t["test"] in self.script_tests[test].get("needs", ()) and t["result"] != "pass"
                ]
                if failed:
                    not_run[test] = f"it needs {' and '.join(failed)} to pass first"
                    continue
                event("fpga-test-started", {"test": test})
                report["tests"].append(self.run_script_test(test, host, runner, facts))
                done = report["tests"][-1]
                event("fpga-test-finished", {"test": test, "result": done["result"], "reason": done.get("reason", "")})
            for test in tests:
                if test in unwired:
                    report.setdefault("warnings", []).append(f"{test} not tested: {unwired[test]}")
                    continue
                # a test that needs a fact test (the Fomu's DFU loads need foboot) is not run when that did not pass
                failed = [t["test"] for t in report["tests"] if t["test"] in self.tests[test].get("needs", ())
                          and t["result"] != "pass"]  # fmt: skip
                if failed:
                    not_run[test] = f"it needs {' and '.join(failed)} to pass first"
                    continue
                event("fpga-test-started", {"test": test})
                blocked = self.before_test(test, variant, host, report, runner)
                report["tests"].append(blocked or self.run_test(test, variant, host, images, manifest, runner))
                done = report["tests"][-1]
                event("fpga-test-finished", {"test": test, "result": done["result"], "reason": done.get("reason", "")})
            if not_run:
                report["not_run"] = not_run
            if not refused and manifest is not None and variant in self.left_running:  # last: nothing follows it
                left, why_not = self.leave_running(variant, host, images, manifest, runner)
                if left:
                    report["left_running"] = left
                else:
                    name = self.left_running[variant]["design"]
                    report.setdefault("warnings", []).append(
                        f"the {name} design, which the check leaves running, could not be loaded ({why_not}): the "
                        "board is left as its last test left it")  # fmt: skip
            closing = None if refused else self.finish(variant, host, found, report, runner)
            if closing:  # what the board is left as, judged like a test (the Fomu: foboot back on USB, #135)
                event("fpga-test-started", {"test": closing["test"]})
                report["tests"].append(closing)
                event("fpga-test-finished", {"test": closing["test"], "result": closing["result"],
                                             "reason": closing.get("reason", "")})  # fmt: skip
        if held["stopped"]:
            report["services_stopped"] = held["stopped"]
        jtag = report.get("jtag", {})
        state = self.identity({**found, "variant": variant, "idcode": jtag.get("idcode") or found.get("idcode"),
                               "dna": jtag.get("dna")})  # fmt: skip
        if "flash_jedec" in flash_ident:  # the flash's JEDEC ID is the identity's, read by openFPGALoader
            state["flash_jedec"] = flash_ident["flash_jedec"]
        results = [t["result"] for t in report["tests"]]
        facts_failed = [f"{k}: {v}" for k, v in facts.items() if k.endswith(identity.ERROR_SUFFIX)]
        facts_failed += flash_faults
        if facts_failed:
            results.append("error")
        try:
            flash = self.read_flash(host, variant, runner)
            if flash:
                state["flash"] = flash
            else:
                report["flash_note"] = self.flash_note
        except Problem as p:
            report["flash_error"] = p.reason
            results.append(p.result)
        if held["failed"]:
            report["services_failed"] = held["failed"]
            results.append("error")
        if refused:
            results.append(refused.result)
        report["state"] = state
        untested = [f"{test} not run: {why}" for test, why in report.get("not_run", {}).items()
                    if checks.UNTESTED_FAILS or test not in not_yet]  # fmt: skip
        if untested:
            results.append("fail")
        report["result"] = worst(results)
        bad = [t for t in report["tests"] if t["result"] != "pass"]
        reasons = [f"{t['test']} {t['result']}: {t.get('reason', '')}" for t in bad] + untested + facts_failed
        reasons += held["failed"]
        if refused:
            reasons.insert(0, refused.reason)
        if reasons:
            report["reason"] = "; ".join(reasons)
        elif "flash_error" in report:
            report["reason"] = report["flash_error"]
        return report
