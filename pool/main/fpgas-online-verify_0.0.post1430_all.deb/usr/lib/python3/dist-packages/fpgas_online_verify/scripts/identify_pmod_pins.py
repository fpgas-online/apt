#!/usr/bin/env python3
"""Scan RPi GPIO pins and decode FPGA pin identification strings.

The FPGA continuously transmits each pin's FPGA ball name (e.g. "G13\\r\\n")
at 1200 baud 8N1. This script reads each RPi GPIO pin, decodes the UART
data via software bit-banging, and reports the mapping.

Usage:
    # Scan all PMOD HAT GPIOs (default for Arty setup)
    uv run python host/identify_pmod_pins.py

    # Scan specific GPIOs
    uv run python host/identify_pmod_pins.py --gpios 6 13 19 26

    # Use a predefined HAT port list
    uv run python host/identify_pmod_pins.py --hat-port JA

Requirements:
    - Raspberry Pi with PMOD HAT connected to FPGA
    - FPGA programmed with matching pmod_pin_id bitstream
    - python3-libgpiod installed (v1.6+ or v2.x)
"""

import argparse
import pathlib
import re
import subprocess
import sys
import time

# gpiod only exists on the Raspberry Pi (it wraps libgpiod). Guard the import
# so the board mapping + validation logic in this module can be imported and
# unit-tested on a development machine without the native library present.
# Any code path that actually reads GPIO raises a clear error if gpiod is None.
try:
    import gpiod
except ImportError:  # pragma: no cover - exercised only off-target
    gpiod = None

# -- PMOD HAT GPIO definitions ------------------------------------------------

# RPi BCM GPIO numbers for each PMOD HAT port, in PMOD pin order
# (pins 1-4 top row, pins 7-10 bottom row).
# Source: DesignSpark.Pmod HAT.py driver + Digilent PMOD HAT schematic.
# Note: JA pins 2-4 and JB pins 2-4 share the same GPIOs (SPI bus).
PMOD_HAT_PORTS = {
    "JA": [8, 10, 9, 11, 19, 21, 20, 18],
    "JB": [7, 10, 9, 11, 26, 13, 3, 2],
    "JC": [16, 14, 15, 17, 4, 12, 5, 6],
}

# All PMOD HAT GPIOs in a flat list (deduplicated, since JA/JB share pins 2-4).
_seen = set()
ALL_HAT_GPIOS = []
for port_name in ["JA", "JB", "JC"]:
    for gpio in PMOD_HAT_PORTS[port_name]:
        if gpio not in _seen:
            _seen.add(gpio)
            ALL_HAT_GPIOS.append(gpio)

# PMOD HAT pin labels for display (port + physical pin number).
HAT_GPIO_LABELS = {}
for port_name, gpios in PMOD_HAT_PORTS.items():
    pmod_phys = [1, 2, 3, 4, 7, 8, 9, 10]
    for gpio, phys in zip(gpios, pmod_phys):
        HAT_GPIO_LABELS[gpio] = f"HAT {port_name} pin {phys:02d}"

# -- Board pin maps (for --board validation mode) ------------------------------

# Expected RPi-BCM-GPIO -> FPGA-ball mappings used by `--board` mode to *verify*
# physical wiring (not just discover it). Each pin is (gpio, fpga_ball, label).
# When the FPGA runs the matching pmod_pin_id bitstream, the ball connected to
# each GPIO transmits its own name, so a correct decode == correct wiring.
BOARDS = {
    # Sqrl Acorn CLE-215+ / LiteFury P2 header, wired to the RPi 5 GPIO header
    # via an adapted Pico-EZmate cable with the fleet's null-modem crossover:
    # FPGA TX (K2) lands on the Pi's RXD0 (GPIO15) and FPGA RX (J2) on the
    # Pi's TXD0 (GPIO14). See docs/hardware/acorn-pinmap.md, "Measured P2
    # wiring (Welland, 2026-08-31)".
    "acorn": {
        "description": "Acorn CLE-215+ / LiteFury P2 header -> RPi 5 GPIO",
        "pins": [
            (15, "K2", "P2.1 Serial TX -> Pi RXD0"),
            (14, "J2", "P2.2 Serial RX <- Pi TXD0"),
            (3, "J5", "P2.3 Spare GPIO 0"),
            (4, "H5", "P2.4 Spare GPIO 1"),
        ],
    },
    # Arty A7 on a Digilent Pmod HAT, cabled straight through: HAT JA -> Arty
    # JA, JB -> JB, JC -> JC (docs/hardware/arty-a7-pin-mapping.md, "PMOD
    # Cable Routing"). Arty JD is not connected.
    #
    # Left out: GPIO10/9/11. They are HAT JA pins 2-4 *and* JB pins 2-4, so two
    # cables drive them at once and whichever wins is read (JB's balls at PS1,
    # JC's at Welland): they cannot tell a good cable from a bad one.
    #
    # Arty JC pins 1 and 2 read V12 and U12, the reverse of Digilent's order,
    # wherever that connector is cabled: on PS1's pi9 (HAT JC) and on all four
    # Welland Artys (HAT JA), 2026-03-17 and 2026-09-29. That follows the
    # connector, not the cable, so it is expected here.
    "arty": {
        "description": "Arty A7 Pmod JA/JB/JC -> Digilent Pmod HAT JA/JB/JC",
        "wires": 24,
        "untested": "HAT JA.2-4 and JB.2-4, which share GPIO10/9/11: this board's design sends on both at once",
        "pins": [
            (8, "G13", "HAT JA.1 <- Arty JA.1"),
            (19, "D13", "HAT JA.7 <- Arty JA.7"),
            (21, "B18", "HAT JA.8 <- Arty JA.8"),
            (20, "A18", "HAT JA.9 <- Arty JA.9"),
            (18, "K16", "HAT JA.10 <- Arty JA.10"),
            (7, "E15", "HAT JB.1 <- Arty JB.1"),
            (26, "J17", "HAT JB.7 <- Arty JB.7"),
            (13, "J18", "HAT JB.8 <- Arty JB.8"),
            (3, "K15", "HAT JB.9 <- Arty JB.9"),
            (2, "J15", "HAT JB.10 <- Arty JB.10"),
            (16, "V12", "HAT JC.1 <- Arty JC.1"),
            (14, "U12", "HAT JC.2 <- Arty JC.2"),
            (15, "V10", "HAT JC.3 <- Arty JC.3"),
            (17, "V11", "HAT JC.4 <- Arty JC.4"),
            (4, "U14", "HAT JC.7 <- Arty JC.7"),
            (12, "V14", "HAT JC.8 <- Arty JC.8"),
            (5, "T13", "HAT JC.9 <- Arty JC.9"),
            (6, "U13", "HAT JC.10 <- Arty JC.10"),
        ],
    },
    # TT FPGA demo board on a Digilent Pmod HAT, as the Welland hosts are cabled:
    # ui_in on HAT JA, uio on JB, uo_out on JC (docs/hardware/tt-fpga-pin-mapping.md).
    # The iCE40 transmits its package pin numbers. All 24 wires are checked (#142).
    # GPIO10/9/11 are each listed twice: they are HAT JA pins 2-4 *and* JB pins
    # 2-4, so two wires end on each. The TT design gives the two FPGA pins their
    # turns to send there (pmod_pin_id_tt.py), and the scan listens for a whole
    # cycle and expects both pin numbers.
    "tt": {
        "description": "TT FPGA demo board Pmods -> Digilent Pmod HAT JA/JB/JC",
        "wires": 24,
        "pins": [
            (8, "13", "HAT JA.1 <- ui_in[0]"),
            (10, "19", "HAT JA.2 <- ui_in[1]"),
            (9, "18", "HAT JA.3 <- ui_in[2]"),
            (11, "21", "HAT JA.4 <- ui_in[3]"),
            (19, "23", "HAT JA.7 <- ui_in[4]"),
            (21, "25", "HAT JA.8 <- ui_in[5]"),
            (20, "26", "HAT JA.9 <- ui_in[6]"),
            (18, "27", "HAT JA.10 <- ui_in[7]"),
            (7, "2", "HAT JB.1 <- uio[0]"),
            (10, "4", "HAT JB.2 <- uio[1]"),
            (9, "3", "HAT JB.3 <- uio[2]"),
            (11, "6", "HAT JB.4 <- uio[3]"),
            (26, "9", "HAT JB.7 <- uio[4]"),
            (13, "10", "HAT JB.8 <- uio[5]"),
            (3, "11", "HAT JB.9 <- uio[6]"),
            (2, "12", "HAT JB.10 <- uio[7]"),
            (16, "38", "HAT JC.1 <- uo_out[0]"),
            (14, "42", "HAT JC.2 <- uo_out[1]"),
            (15, "43", "HAT JC.3 <- uo_out[2]"),
            (17, "44", "HAT JC.4 <- uo_out[3]"),
            (4, "45", "HAT JC.7 <- uo_out[4]"),
            (12, "46", "HAT JC.8 <- uo_out[5]"),
            (5, "47", "HAT JC.9 <- uo_out[6]"),
            (6, "48", "HAT JC.10 <- uo_out[7]"),
        ],
    },
}


# Every FPGA ball on the Arty's four Pmods, by connector (docs/hardware/arty-a7.md, "PMOD FPGA Pin Assignments"),
# so that a wire from a connector the map does not expect (JD, or JC on HAT JA) is named in the routing line.
ARTY_PMODS = {
    "Arty JA": ("G13", "B11", "A11", "D12", "D13", "B18", "A18", "K16"),
    "Arty JB": ("E15", "E16", "D15", "C15", "J17", "J18", "K15", "J15"),
    "Arty JC": ("U12", "V12", "V10", "V11", "U14", "V14", "T13", "U13"),
    "Arty JD": ("D4", "D3", "F4", "F3", "E2", "D2", "H2", "G2"),
}
BOARDS["arty"]["sources"] = {ball: conn for conn, balls in ARTY_PMODS.items() for ball in balls}


def sources(board_name):
    """FPGA ball -> the board connector (or TT bus) it is on: from the map's own labels ("HAT JA.1 <- Arty JA.1"
    is on "Arty JA", "HAT JC.1 <- uo_out[0]" on "uo_out"), and the board's `sources` for balls the map leaves out."""
    spec = BOARDS[board_name]
    out = {}
    for _gpio, ball, label in spec["pins"]:
        if " <- " in label:
            out[ball] = re.split(r"[.\[]", label.split(" <- ", 1)[1], maxsplit=1)[0]
    out.update(spec.get("sources", {}))
    return out


def routing(board_name, rows):
    """One line saying where each HAT connector's wires come from, as read: "HAT JA reads Arty JC, HAT JB reads
    Arty JD, HAT JC reads Arty JB (no signal on HAT JA.10)". It has no "; ": the board's reason joins its tests'
    reasons with that. None for a map that is not of HAT connectors (the Acorn's P2 header). A connector whose
    wires come from more than one place names each, most wires first; a ball no connector has is named as
    itself, and a garbled decode as "garbled"."""
    known = sources(board_name)
    heard, silent = {}, []
    for r in rows:
        if not r["label"].startswith("HAT ") or " <- " not in r["label"]:
            return None
        pin = r["label"].split(" <- ", 1)[0]  # "HAT JA.10"
        from_ = heard.setdefault(pin.split(".", 1)[0], {})
        # A wire that matched counts as its own label: on a GPIO two wires share, both wires' labels are heard.
        got = [r["expected"]] if r["ok"] else r["got"].split("+") if r["got"] else []
        if not got:
            silent.append(pin)
        for label in got:
            where = "garbled" if label.startswith("?") else known.get(label, label)
            from_[where] = from_.get(where, 0) + 1
    said = []
    for hat, from_ in heard.items():
        ranked = sorted(from_, key=lambda where: -from_[where])  # stable: first heard first among equals
        said.append(f"{hat} reads {' and '.join(ranked) if ranked else 'nothing'}")
    return ", ".join(said) + (f" (no signal on {', '.join(silent)})" if silent else "")


def evaluate_board(board_name, results):
    """Validate decoded pin labels against a board's expected wiring.

    *results* maps ``gpio -> decoded_label`` as produced by :func:`scan_gpios`
    (a clean ball name like ``"K2"``, a ``"?garbled"`` string, or ``None`` for
    no signal; for a GPIO two wires end on, a tuple of the labels heard there).
    Returns ``(all_ok, rows)`` where each row is a dict with
    ``gpio``, ``label``, ``expected``, ``got`` and ``ok``. A pin passes only on
    an exact clean match — garbled and missing decodes both fail, because a
    miswired or unprogrammed board must not be reported as good. On a shared
    GPIO a wire passes when its own label is among those heard: each of the
    two wires has its own row and its own label.
    """
    spec = BOARDS[board_name]
    rows = []
    all_ok = True
    for gpio, expected, label in spec["pins"]:
        got = results.get(gpio)
        if isinstance(got, tuple):
            ok = expected in got
            got = "+".join(got)
        else:
            ok = got == expected
        if not ok:
            all_ok = False
        rows.append(
            {"gpio": gpio, "label": label, "expected": expected, "got": got, "ok": ok}
        )
    return all_ok, rows


# -- UART bit-bang parameters --------------------------------------------------

BAUD_RATE = 1200
BIT_PERIOD = 1.0 / BAUD_RATE  # ~833µs


# -- GPIO chip detection -------------------------------------------------------

GPIO_CHIP_LABELS = {
    "pinctrl-rp1",       # RPi 5
    "pinctrl-bcm2711",   # RPi 4
    "pinctrl-bcm2835",   # RPi 3 / Zero
}

_GPIOD_V2 = hasattr(gpiod, "request_lines")


def detect_gpio_chip():
    """Find the gpiochip device for RPi GPIO by label."""
    if gpiod is None:
        raise RuntimeError(
            "python3-libgpiod (the `gpiod` module) is not installed. "
            "Pin scanning requires it; install it on the Raspberry Pi."
        )
    for chip_path in sorted(pathlib.Path("/dev").glob("gpiochip*")):
        try:
            chip = gpiod.Chip(str(chip_path))
            label = chip.get_info().label if _GPIOD_V2 else chip.label()
            chip.close()
            if label in GPIO_CHIP_LABELS:
                return str(chip_path)
        except (OSError, PermissionError):
            continue
    raise RuntimeError(
        "Cannot find GPIO chip with a known label. Is this a Raspberry Pi?"
    )


# -- Single-pin GPIO reader ---------------------------------------------------

class GpioReader:
    """Capture edge events on a single GPIO pin using gpiod (v1 or v2).

    Edge events carry kernel timestamps, so the UART decode is immune to
    Python scheduling jitter. (A polling sampler was used before; on the
    Pi 5 Acorn hosts it mis-framed bytes on some pins while gpiomon on the
    same line showed a clean 1200-baud signal, 2026-09-03.)
    """

    def __init__(self, gpio_num, chip_path):
        self.gpio_num = gpio_num
        self.chip_path = chip_path
        self._request = None  # v2
        self._chip = None     # v1
        self._line = None     # v1

    def open(self):
        if _GPIOD_V2:
            self._request = gpiod.request_lines(
                self.chip_path,
                consumer="pmod-pin-id",
                config={
                    (self.gpio_num,): gpiod.LineSettings(
                        direction=gpiod.line.Direction.INPUT,
                        edge_detection=gpiod.line.Edge.BOTH,
                        bias=gpiod.line.Bias.PULL_UP,
                    ),
                },
            )
        else:
            self._chip = gpiod.Chip(self.chip_path)
            self._line = self._chip.get_line(self.gpio_num)
            self._line.request(
                consumer="pmod-pin-id",
                type=gpiod.LINE_REQ_EV_BOTH_EDGES,
                flags=gpiod.LINE_REQ_FLAG_BIAS_PULL_UP,
            )

    def capture_edges(self, duration_s):
        """Collect edge events for *duration_s*.

        Returns a list of ``(level_after_edge, timestamp_ns)`` tuples in
        time order, where level is 1 for a rising edge and 0 for a falling one.
        """
        events = []
        deadline = time.monotonic() + duration_s
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            if _GPIOD_V2:
                if not self._request.wait_edge_events(remaining):
                    break
                for ev in self._request.read_edge_events():
                    rising = ev.event_type == gpiod.EdgeEvent.Type.RISING_EDGE
                    events.append((1 if rising else 0, ev.timestamp_ns))
            else:
                if not self._line.event_wait(sec=int(remaining), nsec=int((remaining % 1) * 1e9)):
                    break
                ev = self._line.event_read()
                rising = ev.type == gpiod.LineEvent.RISING_EDGE
                events.append((1 if rising else 0, ev.sec * 1_000_000_000 + ev.nsec))
        return events

    def close(self):
        if _GPIOD_V2:
            if self._request:
                self._request.release()
                self._request = None
        else:
            if self._line:
                self._line.release()
                self._line = None
            if self._chip:
                self._chip.close()
                self._chip = None


# -- UART decoder (from edge timestamps) --------------------------------------

def _level_at(events, i, ts):
    """Line level at time *ts*, given that events[i] is the first edge at or
    before the frame start. The level before an edge is its complement."""
    level = 1 - events[i][0]
    j = i
    while j < len(events) and events[j][1] <= ts:
        level = events[j][0]
        j += 1
    return level


def _decode_from(events, start, bit_ns):
    """Decode frames beginning the search at events[start].

    A falling edge is tried as a start bit; if the stop bit reads low the
    frame is rejected and the search moves to the very next edge (standard
    UART resynchronisation), otherwise the frame is kept and the search
    resumes after it. Without the reject-and-step rule a capture that begins
    mid-byte can alias onto the wrong falling edge of a periodic message and
    stay there for the whole capture.
    """
    frames = []
    i = start
    while i < len(events):
        level, t0 = events[i]
        if level != 0:  # only a falling edge can start a frame
            i += 1
            continue
        byte = 0
        for k in range(8):
            byte |= _level_at(events, i, t0 + (1.5 + k) * bit_ns) << k
        stop_ok = _level_at(events, i, t0 + 9.5 * bit_ns) == 1
        if not stop_ok:
            frames.append((byte, False))
            i += 1
            continue
        frames.append((byte, True))
        frame_end = t0 + 9.5 * bit_ns
        while i < len(events) and events[i][1] < frame_end:
            i += 1
    return frames


def decode_edges(events, baud=BAUD_RATE, max_start_candidates=12):
    """Decode 8N1 frames from ``(level_after_edge, timestamp_ns)`` edges.

    The capture may begin at any phase of the transmitted message, and some
    wrong phases still yield frames with a plausible stop bit. So the decode
    is attempted from each of the first *max_start_candidates* falling edges
    and the attempt with the most clean frames (fewest rejected ones) wins.
    Returns ``[(byte, stop_bit_ok)]`` for the winning attempt.
    """
    bit_ns = 1e9 / baud
    starts = [i for i, (level, _t) in enumerate(events) if level == 0][:max_start_candidates]
    best = []
    best_score = None
    for start in starts:
        frames = _decode_from(events, start, bit_ns)
        good = sum(1 for _b, ok in frames if ok)
        bad = len(frames) - good
        score = (good, -bad)
        if best_score is None or score > best_score:
            best, best_score = frames, score
    return best


# Expected label format: FPGA pin names are 2-4 alphanumeric characters.
# Examples: "G13", "B11", "A9", "K16", "V14" (Xilinx 7-series ball names)
# Also accepts PMOD-style names like "JA01" for backwards compatibility, and
# the iCE40's package pin numbers ("2" to "48"), which is what the TT FPGA and
# Fomu designs send: without them every TT pin read as garbled.
_LABEL_PATTERN = re.compile(r'^(?:[A-Z][A-Za-z0-9]{1,3}|[1-9][0-9]?)$')


def is_valid_label(label):
    """Check if a decoded label looks like a valid pin identifier."""
    return bool(_LABEL_PATTERN.match(label))


def label_from_frames(frames):
    """Turn decoded frames into the pin label the FPGA is transmitting.

    Lines are split on ``\\n`` with a trailing ``\\r`` stripped. Returns the
    most common *valid* label, a ``"?<raw>"`` marker if there was signal but
    no valid label (so a miswired or unclocked pin is visible), or ``None``
    when nothing was received.
    """
    from collections import Counter

    text = bytes(b for b, _ok in frames).decode("latin-1")
    lines = [ln.rstrip("\r") for ln in text.split("\n")]
    lines = [ln for ln in lines if ln]
    valid = [ln for ln in lines if is_valid_label(ln)]
    if valid:
        return Counter(valid).most_common(1)[0][0]
    if lines:
        return "?" + Counter(lines).most_common(1)[0][0]
    return None


def labels_from_frames(frames, min_repeats=3):
    """Every valid label heard at least *min_repeats* times, as a sorted tuple.

    For a GPIO two wires end on, where two FPGA pins send in turn: both labels
    are there. A label heard once or twice is not kept: a capture that starts
    or ends inside a label, or noise, can make one. Falls back to
    :func:`label_from_frames`'s ``"?<raw>"`` marker or ``None`` when no label
    was heard often enough.
    """
    from collections import Counter

    text = bytes(b for b, _ok in frames).decode("latin-1")
    lines = [ln.rstrip("\r") for ln in text.split("\n")]
    counts = Counter(ln for ln in lines if ln and is_valid_label(ln))
    heard = tuple(sorted(label for label, n in counts.items() if n >= min_repeats))
    if heard:
        return heard
    one = label_from_frames(frames)
    return one if one is None or one.startswith("?") else "?" + one


# 1200 baud, "XNN\r\n" is 5 frames = 50 bit periods = ~42 ms per repeat;
# 250 ms captures at least five repeats for the vote.
CAPTURE_SECONDS = 0.25
# A GPIO two wires end on: the two FPGA pins take turns of 0.4 s with 0.1 s of
# silence between (pmod_pin_id_tt.py: one cycle is 1.0 s). 1.3 s holds a whole
# turn of each wherever in the cycle the capture starts.
SHARED_CAPTURE_SECONDS = 1.3


def identify_pin(reader, capture_s=CAPTURE_SECONDS):
    """Capture edges for *capture_s* and return the transmitted label.

    Returns the label string (e.g. "K2"), a "?<raw>" marker for a garbled
    signal, or None when the line is silent.
    """
    events = reader.capture_edges(capture_s)
    return label_from_frames(decode_edges(events))


# -- Scanner -------------------------------------------------------------------

def identify_shared_pin(reader, capture_s=SHARED_CAPTURE_SECONDS):
    """Capture a whole cycle of turns and return the labels heard: a sorted
    tuple, a "?<raw>" marker, or None when the line is silent."""
    events = reader.capture_edges(capture_s)
    return labels_from_frames(decode_edges(events, max_start_candidates=24))


def scan_gpios(gpio_list, chip_path, shared=()):
    """Scan a list of GPIO pins and return {gpio: label} mapping. A GPIO in
    *shared* is one two wires end on: it is listened to for a whole cycle of
    turns, and its entry is a tuple of the labels heard."""
    results = {}
    for gpio_num in gpio_list:
        hat_label = HAT_GPIO_LABELS.get(gpio_num, f"GPIO{gpio_num}")
        reader = GpioReader(gpio_num, chip_path)
        try:
            reader.open()
            label = identify_shared_pin(reader) if gpio_num in shared else identify_pin(reader)
            results[gpio_num] = label
            if isinstance(label, tuple):
                print(f"  GPIO{gpio_num:2d} ({'two wires end here':20s}) -> {' and '.join(label)}")
            elif label is None:
                print(f"  GPIO{gpio_num:2d} ({hat_label:20s}) -> (no signal)")
            elif label.startswith("?"):
                print(f"  GPIO{gpio_num:2d} ({hat_label:20s}) -> (garbled: {label[1:]!r})")
            else:
                print(f"  GPIO{gpio_num:2d} ({hat_label:20s}) -> {label}")
        except OSError as e:
            print(f"  GPIO{gpio_num:2d} ({hat_label:20s}) -> ERROR: {e}")
            results[gpio_num] = None
        finally:
            reader.close()
    return results


def print_mapping_table(results):
    """Print a formatted mapping table suitable for documentation."""
    valid = {gpio: label for gpio, label in results.items()
             if label and not label.startswith("?")}
    garbled = {gpio: label for gpio, label in results.items()
               if label and label.startswith("?")}
    no_signal = {gpio for gpio, label in results.items() if label is None}

    if not valid and not garbled:
        print("\nNo FPGA pins detected on any GPIO.")
        return

    print(f"\n=== Pin Mapping Table ({len(valid)} confirmed, "
          f"{len(garbled)} garbled, {len(no_signal)} no signal) ===\n")
    print("| RPi GPIO | HAT Location           | FPGA Pin |")
    print("|----------|------------------------|----------|")
    for gpio in sorted(valid.keys()):
        hat_label = HAT_GPIO_LABELS.get(gpio, f"GPIO{gpio}")
        fpga_pin = valid[gpio]
        print(f"| GPIO{gpio:<4d} | {hat_label:<22s} | {fpga_pin:<8s} |")

    # Also print by FPGA pin for reverse lookup.
    print("\n=== Reverse Mapping (by FPGA pin) ===\n")
    print("| FPGA Pin | RPi GPIO | HAT Location           |")
    print("|----------|----------|------------------------|")
    for gpio, fpga_pin in sorted(valid.items(), key=lambda x: x[1]):
        hat_label = HAT_GPIO_LABELS.get(gpio, f"GPIO{gpio}")
        print(f"| {fpga_pin:<8s} | GPIO{gpio:<4d} | {hat_label:<22s} |")

    if garbled:
        print("\n=== Garbled Pins (signal present, decode failed) ===\n")
        for gpio in sorted(garbled.keys()):
            hat_label = HAT_GPIO_LABELS.get(gpio, f"GPIO{gpio}")
            print(f"  GPIO{gpio:<4d} ({hat_label}): {garbled[gpio][1:]!r}")


# -- Kernel module management --------------------------------------------------

# Modules that claim GPIO pins used by PMOD HAT ports.
# SPI0 uses GPIO7-11 (JA pin 1, JB pin 1, and shared pins 2-4).
# I2C1 uses GPIO2-3 (JB pins 9-10). i2c_bcm2835 often can't be
# unloaded at runtime, but gpiod can usually still read these pins.
_MODULES_TO_UNLOAD = [
    "spidev",
    "spi_bcm2835",
]


_PINCTRL_RE = re.compile(r"^\s*(\d+):\s+(a\d)\b", re.M)


def alt_functions(gpio_list, run=subprocess.run):
    """{gpio: "aN"} for the scanned pins that are set to an alternate function (UART, I2C, SPI).

    Reading a pin through libgpiod leaves it a plain GPIO input, so without this the scan cut the Pi's own
    UART on GPIO14/15 until the next reboot (four Welland NeTV2 Pis, 2026-09-29). Empty without pinctrl.
    """
    try:
        out = run(["pinctrl", "get", ",".join(map(str, gpio_list))], capture_output=True, text=True).stdout
    except OSError:
        return {}
    return {int(gpio): func for gpio, func in _PINCTRL_RE.findall(out) if int(gpio) in gpio_list}


def restore_alt_functions(functions, run=subprocess.run):
    """Set each pin back to the alternate function alt_functions() found."""
    for gpio, func in sorted(functions.items()):
        try:
            run(["pinctrl", "set", str(gpio), func], capture_output=True, text=True)
        except OSError as e:
            print(f"Could not restore GPIO{gpio} to {func}: {e}")
            return
    if functions:
        print("Restored " + ", ".join(f"GPIO{g}={f}" for g, f in sorted(functions.items())))


def release_kernel_gpio_drivers():
    """Unload kernel modules that claim GPIO pins used by PMOD ports.

    SPI0 claims GPIO7-11 which are on HAT ports JA/JB pins 1-4.
    """
    unloaded = []
    for mod in _MODULES_TO_UNLOAD:
        result = subprocess.run(
            ["rmmod", mod], capture_output=True, text=True
        )
        if result.returncode == 0:
            unloaded.append(mod)
    if unloaded:
        print(f"Unloaded kernel modules: {', '.join(unloaded)}")
    else:
        print("No kernel modules needed unloading.")


# -- Board validation output ---------------------------------------------------

def print_validation(board_name, rows):
    """Print a per-pin expected-vs-decoded table for `--board` mode."""
    spec = BOARDS[board_name]
    print(f"\n=== Wiring check: {board_name} ({spec['description']}) ===\n")
    print("| RPi GPIO | Header pin         | Expect | Got    | OK |")
    print("|----------|--------------------|--------|--------|----|")
    for r in rows:
        got = r["got"] if r["got"] is not None else "(none)"
        mark = "✓" if r["ok"] else "✗"
        print(
            f"| GPIO{r['gpio']:<4d} | {r['label']:<18s} | {r['expected']:<6s}"
            f" | {got:<6s} | {mark}  |"
        )


def coverage(board_name):
    """One line saying how many of the board's signal wires the check covers, so
    that "18/18 pins match" is never read as "every wire was tested"."""
    spec = BOARDS[board_name]
    tested = len(spec["pins"])
    wires = spec.get("wires", tested)
    if tested == wires:
        return f"All {wires} signal wires of this cabling are tested."
    return (f"{tested} of the {wires} signal wires of this cabling are tested; "
            f"{wires - tested} are NOT tested: {spec['untested']}.")


# -- Main ----------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Identify FPGA pins via UART transmission at 1200 baud"
    )
    parser.add_argument(
        "--board", choices=sorted(BOARDS),
        help="Validate wiring for a known board against its expected GPIO->ball "
             "map (prints RESULT: PASS/FAIL). An explicit --gpios/--hat-port "
             "scans those pins instead (fpgas-<board>-debug test pin-id -- "
             "--hat-port JA, where the boot check's arguments carry --board).",
    )
    parser.add_argument(
        "--gpios", type=int, nargs="+",
        help="Specific GPIO numbers to scan"
    )
    parser.add_argument(
        "--hat-port", choices=["JA", "JB", "JC"],
        help="Scan all GPIOs on a specific PMOD HAT port"
    )
    parser.add_argument(
        "--no-unload", action="store_true",
        help="Skip unloading kernel modules (SPI, I2C)"
    )
    args = parser.parse_args()
    if args.gpios or args.hat_port:  # an explicit scan is discovery, whatever --board says
        args.board = None

    shared = set()
    if args.board:
        listed = [gpio for gpio, _ball, _label in BOARDS[args.board]["pins"]]
        gpio_list = list(dict.fromkeys(listed))  # each GPIO once, in the table's order
        shared = {gpio for gpio in gpio_list if listed.count(gpio) > 1}
    elif args.gpios:
        gpio_list = args.gpios
    elif args.hat_port:
        gpio_list = PMOD_HAT_PORTS[args.hat_port]
    else:
        gpio_list = ALL_HAT_GPIOS

    if not args.no_unload:
        release_kernel_gpio_drivers()

    chip_path = detect_gpio_chip()

    print("=== FPGA Pin Identification Scanner ===")
    print(f"Baud rate:  {BAUD_RATE}")
    print(f"GPIO chip:  {chip_path}")
    print(f"Scanning:   {len(gpio_list)} GPIO pins")
    print()

    functions = alt_functions(gpio_list)
    try:
        results = scan_gpios(gpio_list, chip_path, shared)
    finally:
        restore_alt_functions(functions)

    # `--board` mode: validate against the expected wiring and emit a single
    # RESULT: marker so verify_hardware.py can score it pass/fail.
    if args.board:
        all_ok, rows = evaluate_board(args.board, results)
        print_validation(args.board, rows)
        n_ok = sum(1 for r in rows if r["ok"])
        print(f"\n{n_ok}/{len(rows)} pins match expected wiring.")
        print(coverage(args.board))
        read = routing(args.board, rows)
        if read:  # the boot check's reason when the test fails (the test's `says`), so the routing is kept
            print(f"PIN-ID: {n_ok}/{len(rows)} pins match: {read}")
        print(f"RESULT: {'PASS' if all_ok else 'FAIL'}")
        sys.exit(0 if all_ok else 1)

    print_mapping_table(results)

    valid_count = sum(1 for v in results.values() if v and not v.startswith("?"))
    garbled_count = sum(1 for v in results.values() if v and v.startswith("?"))
    print(f"\n{valid_count}/{len(gpio_list)} pins identified"
          f" ({garbled_count} garbled).")
    sys.exit(0 if valid_count > 0 else 1)


if __name__ == "__main__":
    main()
