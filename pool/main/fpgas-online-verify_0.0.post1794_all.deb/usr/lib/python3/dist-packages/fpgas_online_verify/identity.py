"""Who each board is: one flat dict per board, the same in the boot report and the fpga-board-identified event.

The field names are rpi-hwid's FpgaBoard fields (FPGABOARD_FIELDS), verbatim, plus fields only fpgas-verify
has (EXTRA_FIELDS). docs/identity.md lists them all, with their types and when each is missing.

  * A key that is not there was not read.
  * A read that was tried and failed is `<field>_error`, the reason in words.
  * Identifiers are lower-case hex, 0x-prefixed, at a fixed width: the device DNA 16 digits (rpi-hwid's
    normalise_id), the IDCODE 8 (all 32 bits), the flash's RDID bytes 1-3 and 4-6 six each. The flash's
    unique ID is bare hex, as rpi-hwid has it.

The dict is the typed form: integers are numbers and booleans booleans. details() is the event form: flat
key=value strings, integers in decimal, booleans "true"/"false", lists and dicts compact JSON, "-" for read
and none, plus schema=fpga-identity/1. document() wraps the dicts of every board found in the versioned
document fpgas-verify --identify prints.

Stdlib only: the Pi hosts boot a tmpfs root with no LiteX.
"""

import datetime
import importlib.metadata
import json
import re

from fpgas_online_verify import idcode

SCHEMA = "fpga-identity/1"  # the event's schema detail
DOCUMENT_SCHEMA = "fpgas-verify/identity"
IDENTITY_VERSION = 1

# rpi-hwid's src/rpi_hwid/model.py FpgaBoard, in its order. tests/test_identity.py pins this list.
FPGABOARD_FIELDS = (
    "kind", "serial", "dna", "idcode", "flash", "flash_jedec", "gateware", "gateware_id", "hw_rev", "mode",
    "trace_id", "dna_sources", "dna_agree", "dna_conflict", "soc_model", "flash_uid", "flash_uid_bits",
    "flash_uid_state", "flash_uid_note", "flash_error", "flash_extended_id", "flash_sfdp", "flash_source",
)  # fmt: skip
# The FpgaBoard fields fpgas-verify fills.
FIELDS = (
    "kind", "serial", "dna", "idcode", "flash", "flash_jedec", "flash_extended_id", "flash_sfdp", "flash_uid",
    "flash_uid_bits", "flash_uid_state", "flash_uid_note", "flash_error", "flash_source", "soc_model",
)  # fmt: skip
# fpgas-verify's own, whose names rpi-hwid does not use.
EXTRA_FIELDS = (
    "board", "variant", "bdf", "usb", "identifier", "build", "flash_size_bytes", "flash_status", "flash_config",
    "flash_quad", "flash_uid_opcode", "idcode_version", "idcode_part_number", "idcode_manufacturer_id",
    "idcode_manufacturer", "idcode_device", "tinytapeout_error", "tinytapeout_note",
)  # fmt: skip
# rpi-hwid's src/rpi_hwid/model.py TinyTapeoutBoard, in its order: a Tiny Tapeout board's fields, as `rpi-hwid
# tinytapeout --json` reads them (boards/tt_fpga.py). tests/test_identity.py pins this list.
TINYTAPEOUT_FIELDS = (
    "usb_serial", "mcu", "shuttle", "chip", "repo", "commit", "demoboard", "demoboard_version", "sdk",
)  # fmt: skip
ERROR_SUFFIX = "_error"
# idcode.decode()'s fields, in this order.
IDCODE_FIELDS = (
    "idcode", "idcode_version", "idcode_part_number", "idcode_manufacturer_id", "idcode_manufacturer",
    "idcode_device",
)  # fmt: skip

# A board module's name -> rpi-hwid's kind. The Acorn's own claims give theirs (kind()).
KINDS = {"acorn": "acorn", "arty": "arty", "netv2": "netv2", "tt": "tt", "fomu": "fomu"}
# What the Acorn module calls a PCIe design it finds -> rpi-hwid's kind.
ACORN_KINDS = {"fpgas-online": "acorn", "sqrl-factory": "acorn", "pcileech": "pcileech"}

DNA_DIGITS, IDCODE_DIGITS, RDID_DIGITS, REGISTER_DIGITS = 16, 8, 6, 2


def hex_id(value, digits):
    """An identifier as lower-case hex, 0x-prefixed, `digits` wide."""
    return f"0x{value:0{digits}x}"


def dna(value):
    """The device DNA (an int, or hex text however a tool spelled it), as rpi-hwid's normalise_id has it."""
    return hex_id(int(value, 16) if isinstance(value, str) else value, DNA_DIGITS)


def known(key):
    """True for a key the dict may have: a field, or a field's _error."""
    fields = (*FIELDS, *EXTRA_FIELDS, *TINYTAPEOUT_FIELDS)
    return key in fields or (key.endswith(ERROR_SUFFIX) and key[: -len(ERROR_SUFFIX)] in fields)


def kind(board_name, found):
    """rpi-hwid's kind for a board found by `board_name`'s module."""
    if board_name == "acorn":
        return ACORN_KINDS.get(found.get("kind"), "unknown-fpga")
    return KINDS.get(board_name, "unknown-fpga")


def base(board_key, board_name, found, variant=None):
    """What every board's dict starts with: board (the state key), kind, variant, and how it was found,
    including the IDCODE when finding the board read it (the NeTV2's scan). A Tiny Tapeout board's USB serial is
    also its usb_serial, the key rpi-hwid and the site know it by."""
    out = {"board": board_key, "kind": kind(board_name, found)}
    variant = variant or found.get("variant")
    if variant:
        out["variant"] = variant
    for key in ("serial", "usb", "bdf"):
        if found.get(key):
            out[key] = found[key]
    if out["kind"] == "tt" and found.get("serial"):  # rpi-hwid's name for a Tiny Tapeout board's USB serial
        out["usb_serial"] = found["serial"]
    if found.get("idcode"):
        codes = found.get("idcodes") or [found["idcode"]]
        entry = idcode.decode(int(codes[0], 16)) if len(codes) == 1 else {"idcode": ", ".join(codes)}
        out.update(idcode_fields(entry))
    return out


def idcode_fields(entry):
    """The IDCODE fields from a JTAG entry: idcode.decode()'s fields, which are already identity fields (and
    maybe result/reason).

    One device on the chain gives the IDCODE and its decoded fields; anything else gives idcode_error."""
    code = entry.get("idcode")
    if code and "," not in code and "idcode_version" in entry:
        out = {key: entry[key] for key in IDCODE_FIELDS}
        out["idcode"] = hex_id(int(code, 16), IDCODE_DIGITS)
        return out
    if code:
        return {"idcode_error": f"the JTAG chain has more than one device ({code})"}
    if entry.get("result") not in (None, "pass"):
        return {"idcode_error": entry.get("reason") or entry["result"]}
    return {}


def dna_fields(entry):
    """The device DNA from a JTAG entry (testbench.TestBoard.jtag): dna, or dna_error saying why there is none."""
    return {key: entry[key] for key in ("dna", "dna_error") if key in entry}


def flash_fields(ident, source):
    """The flash fields from what spi_flash.Flash.identify() read: all six RDID bytes, the part, its size, the
    status and configuration registers, the factory unique ID with how it was read, and the SFDP revision
    ("1.6", or "none" when the part answered without the signature) or why it could not be read."""
    rdid = bytes.fromhex(ident["rdid"])
    out = {"flash_jedec": hex_id(int.from_bytes(rdid[:3], "big"), RDID_DIGITS)}
    if len(rdid) >= 6:
        out["flash_extended_id"] = hex_id(int.from_bytes(rdid[3:6], "big"), RDID_DIGITS)
    if ident.get("part") and ident["part"] != "unknown":
        out["flash"] = ident["part"]
    if ident.get("size_bytes"):
        out["flash_size_bytes"] = ident["size_bytes"]
    for key, name in (("status", "flash_status"), ("config", "flash_config")):
        if ident.get(key) is not None:
            out[name] = hex_id(int(ident[key], 16), REGISTER_DIGITS)
    if ident.get("quad_enabled") is not None:
        out["flash_quad"] = ident["quad_enabled"]
    uid = ident.get("unique_id")
    if uid:
        uid = uid.lower()
        out["flash_uid"] = uid
        out["flash_uid_bits"] = len(uid) * 4
        out["flash_uid_state"] = "blank" if set(uid) <= {"0"} or set(uid) <= {"f"} else "read"
        if ident.get("unique_id_opcode") is not None:
            out["flash_uid_opcode"] = hex_id(ident["unique_id_opcode"], REGISTER_DIGITS)
    if ident.get("sfdp"):
        out["flash_sfdp"] = ident["sfdp"]
    elif ident.get("sfdp_error"):
        out["flash_sfdp_error"] = ident["sfdp_error"]
    out["flash_source"] = source
    return out


# openFPGALoader's --flash-info-json document (the fpgas.online builds; its doc/guide/advanced.rst): the only
# format and version this reads. A version 1 document's "sfdp": null may be a failed read, so it is refused.
FLASH_INFO_FORMAT = "openFPGALoader-flash-info"
FLASH_INFO_VERSION = 2
UID_STATES = ("read", "blank", "none")
_HEX_ID = re.compile(r"0x[0-9a-fA-F]{6}")
_SFDP_REVISION = re.compile(r"[0-9]+\.[0-9]+")


class FlashInfoError(ValueError):
    """An openFPGALoader flash-info document this reader does not take: its message says why."""


def _flash_info_record(doc):
    """The one flash of a --flash-info-json document, checked; FlashInfoError saying why it is not one."""
    if not isinstance(doc, dict):
        raise FlashInfoError("the document is not a JSON object")
    if doc.get("format") != FLASH_INFO_FORMAT:
        raise FlashInfoError(f"its format is {doc.get('format')!r}, not {FLASH_INFO_FORMAT!r}")
    version = doc.get("version")
    if type(version) is not int or version != FLASH_INFO_VERSION:  # True is an int, and no version
        raise FlashInfoError(f"it is version {version!r}; this reader takes only version {FLASH_INFO_VERSION}")
    flashes = doc.get("flashes")
    if not isinstance(flashes, list):
        raise FlashInfoError("it has no list of flashes")
    if len(flashes) != 1:
        raise FlashInfoError(f"it describes {len(flashes)} flashes, not the board's one")
    (flash,) = flashes
    if not isinstance(flash, dict):
        raise FlashInfoError("its flash is not a JSON object")
    for key in ("jedec_id", "extended_id"):
        if key == "extended_id" and flash.get(key) is None:  # null: the part's family defines no bytes 4-6
            continue
        if not isinstance(flash.get(key), str) or not _HEX_ID.fullmatch(flash[key]):
            raise FlashInfoError(f"its {key} is {flash.get(key)!r}, not 0x and 6 hex digits")
    if int(flash["jedec_id"], 16) in (0, 0xFFFFFF):
        raise FlashInfoError(f"its JEDEC ID is {flash['jedec_id']}: no flash answered")
    uid = flash.get("unique_id")
    if not isinstance(uid, dict) or uid.get("state") not in UID_STATES:
        raise FlashInfoError(f"its unique_id state is not one of {', '.join(UID_STATES)}: {uid!r}")
    if uid["state"] in ("read", "blank"):
        if type(uid.get("bits")) is not int or uid["bits"] <= 0:
            raise FlashInfoError(f"its unique_id is {uid['state']} with no length in bits: {uid!r}")
        if not isinstance(uid.get("opcode"), str) or not re.fullmatch(r"0x[0-9a-fA-F]{2}", uid["opcode"]):
            raise FlashInfoError(f"its unique_id is {uid['state']} with no opcode: {uid!r}")
    if uid["state"] == "read":
        value = uid.get("value")
        if not isinstance(value, str) or not re.fullmatch(r"[0-9a-fA-F]+", value) or len(value) * 4 != uid["bits"]:
            raise FlashInfoError(f"its unique_id is read, but its value is not {uid['bits']} bits of hex: {uid!r}")
        if set(value.lower()) <= {"0"} or set(value.lower()) <= {"f"}:  # flash_fields' rule for blank
            raise FlashInfoError(f"its unique_id is read, but {value} is all 0x00 or 0xff: a blank read, not an ID")
    if uid["state"] == "none" and uid.get("note") is not None and not (isinstance(uid["note"], str) and uid["note"]):
        raise FlashInfoError(f"its unique_id note is neither text nor null: {uid!r}")
    sfdp = flash.get("sfdp", ...)
    if sfdp is ...:
        raise FlashInfoError("it has no sfdp (null when the part has none)")
    if sfdp is not None and not (isinstance(sfdp, dict) and isinstance(sfdp.get("revision"), str)
                                 and _SFDP_REVISION.fullmatch(sfdp["revision"])):  # fmt: skip
        raise FlashInfoError(f"its sfdp has no revision major.minor: {sfdp!r}"[:300])
    if flash.get("part") is not None and not (isinstance(flash["part"], str) and flash["part"]):
        raise FlashInfoError(f"its part is {flash['part']!r}, neither text nor null")
    size = flash.get("size_bytes")
    if size is not None and (type(size) is not int or size <= 0):
        raise FlashInfoError(f"its size_bytes is {size!r}, neither a positive number nor null")
    return flash


def flash_info_fields(doc, source):
    """The flash fields from openFPGALoader's --flash-info-json document `doc` (parsed JSON), the same fields
    flash_fields() gives, and flash_uid_note: {"flash_error": why} for a document that is not version 2 of
    that format with exactly one flash.

    The unique ID as openFPGALoader read it: `read` gives flash_uid, flash_uid_bits, flash_uid_opcode; `blank`
    (it read all 0x00 or 0xff) flash_uid_bits and flash_uid_opcode; `none` with a note (the chip said it has
    no unique ID) flash_uid_note. `none` without a note is openFPGALoader knowing no unique ID command for
    the part, which says nothing about the silicon: no flash_uid_note, so rpi-hwid makes no label from it.
    flash_sfdp is the SFDP revision, or "none" when the part answered without the SFDP signature."""
    try:
        flash = _flash_info_record(doc)
    except FlashInfoError as e:
        return {"flash_error": f"openFPGALoader's flash-info JSON is not one this reads: {e}"}
    uid = flash["unique_id"]
    rdid = flash["jedec_id"][2:] + (flash["extended_id"][2:] if flash.get("extended_id") else "")
    # What the chip said, never openFPGALoader's database: its `part` is a lookup of the JEDEC ID, which several
    # parts share (the contract names 0xc22017), so `flash` is left out and rpi-hwid names the family from the
    # JEDEC ID, the extended ID and the SFDP. The size is the SFDP's density, or size_bytes when the chip gave it.
    density = ((flash["sfdp"] or {}).get("bfpt") or {}).get("density_bits")
    if isinstance(density, int) and not isinstance(density, bool) and density > 0 and density % 8 == 0:
        size = density // 8
    else:
        size = flash.get("size_bytes") if flash.get("size_source") != "database" else None
    ident = {"rdid": rdid, "size_bytes": size,
             "sfdp": "none" if flash["sfdp"] is None else flash["sfdp"]["revision"]}  # fmt: skip
    if uid["state"] == "read":
        ident.update(unique_id=uid["value"], unique_id_opcode=int(uid["opcode"], 16))
    out = flash_fields(ident, source)
    out["flash_uid_state"] = uid["state"]
    if uid["state"] == "blank":
        out["flash_uid_bits"] = uid["bits"]
        out["flash_uid_opcode"] = hex_id(int(uid["opcode"], 16), REGISTER_DIGITS)
    elif uid["state"] == "none" and uid.get("note"):
        out["flash_uid_note"] = uid["note"]
    return out


def _version():
    try:
        return importlib.metadata.version("fpgas-online-verify")
    except importlib.metadata.PackageNotFoundError:  # run from a checkout
        return "unknown"


def _check(value, where=""):
    """Raise TypeError unless `value` is a string, integer, boolean or None, or a list, tuple or dict of them
    (to any depth) whose dict keys are strings. The same rules hold at every depth: a float or a non-string
    key is refused inside a list or dict just as at the top."""
    at = f"{where}: " if where else ""
    if value is None or isinstance(value, (str, int)):  # bool is an int
        return
    if isinstance(value, (list, tuple)):
        for i, item in enumerate(value):
            _check(item, f"{where}[{i}]")
        return
    if isinstance(value, dict):
        for key, item in value.items():
            if not isinstance(key, str):
                raise TypeError(f"{at}an identity dict's keys must be strings, not {key!r}")
            _check(item, f"{where}.{key}" if where else key)
        return
    raise TypeError(f"{at}an identity value must be a string, integer, boolean, list, dict or None, not {value!r}")


def detail(value):
    """One value as an event detail (label contract §13, §17): a string as it is; None (read, and there is
    none) "-"; a boolean "true"/"false"; an integer in decimal; a list or dict compact JSON with sorted keys.
    Never a Python repr: any other type, at any depth, is a bug, and raises (_check)."""
    _check(value)
    if value is None:
        return "-"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (str, int)):
        return str(value)
    return json.dumps(value, separators=(",", ":"), sort_keys=True)


def _field(key, value):
    """One field as an event detail: TypeError for a field name that is not a string (as for a nested dict's
    keys, _check) or a value detail() refuses."""
    if not isinstance(key, str):
        raise TypeError(f"an identity's field names must be strings, not {key!r}")
    return detail(value)


def _fields(board):
    if not isinstance(board, dict):
        raise TypeError(f"an identity must be a dict, not {board!r}")
    return board.items()


def details(board):
    """The fpga-board-identified event's details: the dict as flat strings, and its schema. A field not read
    is not in the dict, so not in the details either. A field name that is not a string, or a value detail()
    refuses, raises TypeError naming its field; an identity that is not a dict raises TypeError too."""
    out = {}
    for key, value in _fields(board):
        try:
            out[key] = _field(key, value)
        except TypeError as e:
            raise TypeError(f"identity field {key}: {e}") from None
    out["schema"] = SCHEMA
    return out


def refused(board):
    """The fields (names or values) details() refuses, each with why, so a caller can leave them out and say
    so. An identity that is not a dict has no fields to leave out: TypeError."""
    out = {}
    for key, value in _fields(board):
        try:
            _field(key, value)
        except TypeError as e:
            out[key] = str(e)
    return out


KEEP = "keep_identity"  # the option the runner gives a board's check: called with the dict once it is built


def keep(options, board):
    """Hand the board's dict to the runner as soon as it is built, so a check that stops after sending
    fpga-board-identified still has it in its error report (and so in verify.json and fpga-verified)."""
    (options.get(KEEP) or (lambda board: None))(board)


def document(boards, tool=None, read_at=None):
    """The identity document: every board's dict, with what read them and when. "source" is always "live": a
    run inside fpgas-verify --label prints the outer run's document unchanged, and never builds one."""
    if tool is None:
        tool = f"fpgas-online-verify {_version()}"
    if read_at is None:
        read_at = datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")
    return {
        "schema": DOCUMENT_SCHEMA,
        "identity_version": IDENTITY_VERSION,
        "tool": tool,
        "read_at": read_at,
        "source": "live",
        "boards": [dict(b) for b in boards],
    }
