"""fpgas-tt: Pi-side Tiny Tapeout demo-board bridge daemon for fpgas.online."""

__version__ = "0.1.0"
