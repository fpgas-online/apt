from fpgas_tt.server import main

if __name__ == "__main__":
    raise SystemExit(main())
